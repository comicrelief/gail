# gail
Gift Aid Interface Link (GAIL)

This is the new Master branch of the GAIL library.
