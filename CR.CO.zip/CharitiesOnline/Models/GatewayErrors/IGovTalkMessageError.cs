﻿namespace CharitiesOnline.Models
{
    interface IGovTalkMessageError { }
}
