﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CharitiesOnline.MessageBuilders
{
    public class UnknownMessageBuilder : GovTalkMessageBuilderBase
    {
        public override void SetBody()
        {
            throw new NotImplementedException();
        }
        public override void SetEnvelopeVersion()
        {
            throw new NotImplementedException();
        }
        public override void SetGovTalkDetails()
        {
            throw new NotImplementedException();
        }
        public override void SetHeader()
        {
            throw new NotImplementedException();
        }
    }
}
